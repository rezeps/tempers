import validatetc from "validatetc";


console.log(validatetc("00000000000"));
